﻿using Microsoft.AspNetCore.Mvc;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class EmployeeController : Controller
    {
        List<Employee> employees = null;
        public EmployeeController()
        {
                if(employees == null)
            {
                employees = new List<Employee>() {
                new Employee(){Id=1,Name="AJAY",Batch="NO1",Salary=9000}};
            }
        }
        public IActionResult Index()
        {
        
            return View(employees.ToList());
        }
    }
}
